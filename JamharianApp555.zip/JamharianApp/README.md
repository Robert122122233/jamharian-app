# Jamharian Collection — Android App

Native Android (Kotlin + WebView) wrapper for **https://jamharian.am**.
Package: `am.jamharian.app` · minSdk 26 (Android 8) · targetSdk 36 (Google Play requirement since 31 Aug 2026).

## Features
| Feature | Where |
|---|---|
| Full-screen edge-to-edge WebView, JS + localStorage | `MainActivity.setupWebView()` |
| Hardware Back → website history, exits only on first page | `setupBackButton()` |
| Pull-to-refresh (only when scrolled to top) | `setupSwipeRefresh()` |
| Gold progress bar + branded offline screen with Retry | `activity_main.xml`, `showOffline()` |
| `tel:`, `mailto:`, `sms:`, WhatsApp (`wa.me`, `whatsapp:`), Viber, Telegram, Google Maps, `geo:`, `intent://` | `handleUrl()` |
| Other websites open in the phone's browser | `handleUrl()` |
| File uploads (`<input type="file">`) | `onShowFileChooser()` |
| File downloads → Downloads folder | `setDownloadListener` |
| Firebase push notifications, tap opens a URL | `PushService.kt` |
| Splash screen + adaptive/themed icon from the JC logo | `res/values/themes.xml`, `res/drawable/ic_*` |

## Project structure
```
JamharianApp/
├── build.gradle.kts              # plugin versions
├── settings.gradle.kts
├── gradle.properties
├── gradlew / gradlew.bat / gradle/wrapper/   # Gradle 8.14.3
├── keystore.properties.example   # copy → keystore.properties for release signing
├── .github/workflows/build.yml   # optional: build APK/AAB on GitHub for free
└── app/
    ├── build.gradle.kts          # ← START_URL, versionCode, signing
    ├── proguard-rules.pro
    ├── google-services.json      # ← YOU add this (Firebase)
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/www/index.html # your site, bundled (optional offline-start mode)
        ├── java/am/jamharian/app/
        │   ├── MainActivity.kt
        │   └── PushService.kt
        └── res/
            ├── layout/activity_main.xml
            ├── values/ (strings, colors, themes)
            ├── drawable/ (logo, icon, splash, notification vectors)
            ├── mipmap-anydpi-v26/ (adaptive icons)
            └── xml/network_security_config.xml
```

---

## Step 0 — Website settings (orders + admin) — do this first
The updated site is in **`website/index.html`** (same file is bundled at `app/src/main/assets/www/index.html`).
Settings are at the top of the `<script>` block — search for `ORDER_CONFIG`.

### Telegram order notifications
1. In Telegram open **@BotFather** → `/newbot` → pick a name → copy the **token** (`7123456789:AAH...`).
2. Open your new bot and press **Start** (a bot can't message you until you do).
3. Open **@userinfobot** → it replies with your numeric **Id** = chat ID.
   *For a group:* add the bot to the group, send any message, open
   `https://api.telegram.org/bot<TOKEN>/getUpdates` and copy `"chat":{"id":-100...}`.
4. Paste both:
   ```js
   telegramBotToken: '7123456789:AAH4k...',
   telegramChatId:   '123456789',
   ```
5. Optional email copy: create a form at https://formspree.io, paste its URL into `formspreeEndpoint`.

The order is confirmed to the customer **only after** it reaches you; if sending fails, the cart is kept
and the customer sees "try again". The contact form is sent the same way.

⚠️ The bot token is visible in the page source. Use a bot created **only** for orders. If it is ever abused:
@BotFather → `/revoke` → paste the new token.

### Hidden admin
* The public Admin button is gone. Open the panel at **`https://jamharian.am/#jc-admin`** → password prompt.
* Default password: `Jamharian2026!` — **change it**:
  1. Open the site in Chrome → F12 → Console → run:
     ```js
     crypto.subtle.digest('SHA-256', new TextEncoder().encode('YOUR-NEW-PASSWORD')).then(b => console.log([...new Uint8Array(b)].map(x => x.toString(16).padStart(2,'0')).join('')))
     ```
  2. Paste the printed value into `passwordSha256`.
* Also change `secretHash: 'jc-admin'` to something hard to guess, e.g. `'jc-panel-8k2q'`.

### Publish
Upload `website/index.html` to your hosting (replace the old one). The app loads the live site,
so customers get the fix immediately — even in already-installed apps.

## Step 1 — Install tools (once)
* **Android Studio** (latest) — https://developer.android.com/studio. It installs the Android SDK and JDK 17.
* On first launch: *More Actions → SDK Manager* → install **Android 16 (API 36)** SDK Platform and Build-Tools.

## Step 2 — Set your website URL
In `app/build.gradle.kts`:
```kotlin
buildConfigField("String", "START_URL", "\"https://jamharian.am/\"")
```
Not hosted yet? Use the copy of your site bundled in the app:
```kotlin
buildConfigField("String", "START_URL", "\"file:///android_asset/www/index.html\"")
```
(Still needs internet for Tailwind, fonts and Unsplash images.)

## Step 3 — Build a debug APK (test on your phone)
Open the `JamharianApp` folder in Android Studio (*File → Open*), wait for Gradle sync, then in the Terminal tab:

```bash
# macOS / Linux
./gradlew assembleDebug
# Windows
gradlew.bat assembleDebug
```
Output: `app/build/outputs/apk/debug/app-debug.apk`

Install it:
* **USB:** enable *Developer options → USB debugging* on the phone, then `adb install -r app/build/outputs/apk/debug/app-debug.apk` (or press ▶ Run in Android Studio).
* **Without cable:** send the APK to the phone (Telegram/Drive), open it, allow "Install unknown apps".

## Step 4 — Create your signing key (once — BACK IT UP!)
```bash
keytool -genkeypair -v -keystore jamharian-release.jks -alias jamharian \
  -keyalg RSA -keysize 2048 -validity 10000
```
Put `jamharian-release.jks` in the project root, then:
```bash
cp keystore.properties.example keystore.properties   # and fill in passwords
```
⚠️ If you lose this file or its passwords, you can never update the app outside Google Play. Store copies somewhere safe (not in git).

## Step 5 — Build signed release APK + AAB
```bash
./gradlew assembleRelease     # → app/build/outputs/apk/release/app-release.apk
./gradlew bundleRelease       # → app/build/outputs/bundle/release/app-release.aab
```
* `.apk` → share/install directly.
* `.aab` → upload to Google Play Console (Play requires AAB). Enable **Play App Signing** when asked; your `.jks` becomes the *upload key*.

Check the signature: `apksigner verify --print-certs app/build/outputs/apk/release/app-release.apk`

For each new version, increase `versionCode` (1 → 2 → 3…) and `versionName` in `app/build.gradle.kts`.

---

## Step 6 — Push notifications (Firebase)
1. https://console.firebase.google.com → *Add project* → *Add app → Android*.
2. Package name: `am.jamharian.app` (add a second app `am.jamharian.app.debug` if you want push in debug builds too).
3. Download **google-services.json** → put it in `app/`.
4. Rebuild. The app requests notification permission on Android 13+ and subscribes every device to topic **`all`**.
5. Send: Firebase Console → *Messaging → New campaign → Notifications* → target the app (or topic `all`).
   To open a specific page on tap, add *Custom data*: key `url`, value e.g. `https://jamharian.am/#niche`.

The project builds without `google-services.json`; push is simply inactive until you add it.

## App icon & splash screen
* Generated from your JC logo vector: gold mark on obsidian (`#0E0E0E`).
  * `res/drawable/ic_launcher_foreground.xml` — icon mark
  * `res/drawable/ic_launcher_background.xml` — background colour
  * `res/drawable/ic_splash_logo.xml` + `Theme.Jamharian.Splash` in `themes.xml` — splash
  * `res/drawable/ic_notification.xml` — white status-bar icon
* To use a PNG logo instead: Android Studio → right-click `res` → *New → Image Asset* → *Launcher Icons (Adaptive)* → choose your PNG. It overwrites the files above.
* Play Store listing also needs a 512×512 PNG icon — `play-store-icon-512.png` is included.

## Permissions (AndroidManifest.xml)
| Permission | Why |
|---|---|
| `INTERNET`, `ACCESS_NETWORK_STATE` | load the site, detect offline |
| `POST_NOTIFICATIONS` | push notifications (Android 13+ asks the user) |
| `WRITE_EXTERNAL_STORAGE` (maxSdk 28) | downloads on Android 8–9 only |

`<queries>` lets the app open the dialer, mail, maps and WhatsApp on Android 11+.

## Optional: open jamharian.am links directly in the app
The manifest already declares the link filter. To make Android open them automatically, host
`https://jamharian.am/.well-known/assetlinks.json` with your release SHA-256 fingerprint
(get it with `keytool -list -v -keystore jamharian-release.jks`, or from Play Console → App integrity).

## No Android Studio? Build on GitHub
Push this folder to a GitHub repo → *Actions* tab → workflow **Build Android** runs and produces
a downloadable `jamharian-builds` artifact (debug APK, release APK, AAB).
Add secrets listed in `.github/workflows/build.yml` for signed builds and Firebase.

## Troubleshooting
* **"SDK location not found"** → open once in Android Studio, or create `local.properties` with `sdk.dir=/path/to/Android/sdk`.
* **Release APK named `app-release-unsigned.apk`** → `keystore.properties` missing or wrong path.
* **Blank page** → check the URL is HTTPS with a valid certificate (plain HTTP is blocked).
* **Debug the web page** → debug builds allow `chrome://inspect` from desktop Chrome.
