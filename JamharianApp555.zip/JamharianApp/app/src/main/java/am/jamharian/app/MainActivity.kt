package am.jamharian.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var progress: LinearProgressIndicator
    private lateinit var offlineView: View

    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var pageLoadFailed = false
    private var keepSplash = true

    private val startUrl: String = BuildConfig.START_URL
    private val startHost: String? = Uri.parse(startUrl).host?.removePrefix("www.")

    // ---------- File upload (<input type="file">) ----------
    private val filePicker = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
        fileCallback?.onReceiveValue(uris)
        fileCallback = null
    }

    // ---------- Notification permission (Android 13+) ----------
    private val notifPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* nothing else needed */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        splash.setKeepOnScreenCondition { keepSplash }

        WindowCompat.setDecorFitsSystemWindows(window, false)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        swipe = findViewById(R.id.swipeRefresh)
        progress = findViewById(R.id.progressBar)
        offlineView = findViewById(R.id.offlineView)

        applyInsets()
        setupWebView()
        setupSwipeRefresh()
        setupBackButton()
        findViewById<Button>(R.id.retryButton).setOnClickListener { retry() }

        // Splash never stays longer than ~2.5 s, even on a slow connection
        webView.postDelayed({ keepSplash = false }, 2500)

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
        } else {
            loadUrlOrOffline(intent?.getStringExtra(PushService.EXTRA_URL) ?: intent?.dataString ?: startUrl)
        }

        askNotificationPermission()
        logFcmToken()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Tap on a notification or a jamharian.am link while the app is open
        val target = intent.getStringExtra(PushService.EXTRA_URL) ?: intent.dataString
        if (!target.isNullOrBlank()) loadUrlOrOffline(target)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() {
        super.onPause()
        CookieManager.getInstance().flush() // persist cookies/session
    }

    // Edge-to-edge (required behaviour on targetSdk 35+): keep content clear of system bars
    private fun applyInsets() {
        val root = findViewById<View>(R.id.root)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
            )
            val ime = insets.getInsets(WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, maxOf(bars.bottom, ime.bottom))
            insets
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        with(webView.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true          // your site uses localStorage (cart, wishlist, orders)
            databaseEnabled = true
            loadWithOverviewMode = true
            useWideViewPort = true
            mediaPlaybackRequiresUserGesture = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            userAgentString = "$userAgentString JamharianApp/${BuildConfig.VERSION_NAME}"
        }
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return handleUrl(request.url)
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                pageLoadFailed = false
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView, url: String?) {
                swipe.isRefreshing = false
                progress.visibility = View.GONE
                keepSplash = false
                if (!pageLoadFailed) showOffline(false)
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                // Only the main page failing should show the offline screen (not a single image/font)
                if (request.isForMainFrame) {
                    pageLoadFailed = true
                    showOffline(true)
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                progress.setProgressCompat(newProgress, true)
                progress.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }

            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    val chooser = Intent.createChooser(params.createIntent(), getString(R.string.choose_file))
                    filePicker.launch(chooser)
                    true
                } catch (e: ActivityNotFoundException) {
                    fileCallback = null
                    Toast.makeText(this@MainActivity, R.string.no_app_found, Toast.LENGTH_SHORT).show()
                    false
                }
            }
        }

        // Downloads (PDF invoices, images, etc.)
        webView.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            if (url.startsWith("blob:") || url.startsWith("data:")) {
                Toast.makeText(this, R.string.download_unsupported, Toast.LENGTH_LONG).show()
                return@setDownloadListener
            }
            try {
                val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val req = DownloadManager.Request(Uri.parse(url)).apply {
                    setMimeType(mimeType)
                    addRequestHeader("User-Agent", userAgent)
                    CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                    setTitle(fileName)
                    setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                }
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
                Toast.makeText(this, getString(R.string.downloading, fileName), Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                openExternal(Uri.parse(url))
            }
        }
    }

    /** Returns true if the URL was handled outside the WebView. */
    private fun handleUrl(uri: Uri): Boolean {
        val scheme = uri.scheme?.lowercase() ?: return false
        val host = uri.host?.lowercase()?.removePrefix("www.")

        return when {
            scheme == "tel" -> { start(Intent(Intent.ACTION_DIAL, uri)); true }
            scheme == "mailto" -> { start(Intent(Intent.ACTION_SENDTO, uri)); true }
            scheme == "sms" || scheme == "smsto" -> { start(Intent(Intent.ACTION_SENDTO, uri)); true }
            scheme == "geo" || scheme == "whatsapp" || scheme == "viber" || scheme == "tg" -> {
                openExternal(uri); true
            }
            scheme == "intent" -> { handleIntentScheme(uri.toString()); true }
            scheme == "file" -> false
            scheme == "http" || scheme == "https" -> {
                val external = host != null && (
                    host == "wa.me" || host.endsWith("whatsapp.com") ||
                    host.startsWith("maps.") || host == "goo.gl" || host == "maps.app.goo.gl" ||
                    host.endsWith("instagram.com") || host.endsWith("facebook.com") ||
                    host.endsWith("t.me") || host.endsWith("youtube.com")
                )
                when {
                    external -> { openExternal(uri); true }
                    // Your own site (and the bundled file) stay inside the app
                    host == startHost -> false
                    // Any other website opens in the phone's browser
                    else -> { openExternal(uri); true }
                }
            }
            else -> { openExternal(uri); true }
        }
    }

    private fun handleIntentScheme(url: String) {
        try {
            val intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME).apply {
                addCategory(Intent.CATEGORY_BROWSABLE)
                component = null
                selector = null
            }
            startActivity(intent)
        } catch (e: Exception) {
            val fallback = Regex("S\\.browser_fallback_url=([^;]+)").find(url)?.groupValues?.get(1)
            if (fallback != null) webView.loadUrl(Uri.decode(fallback))
        }
    }

    private fun openExternal(uri: Uri) = start(Intent(Intent.ACTION_VIEW, uri))

    private fun start(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.no_app_found, Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupSwipeRefresh() {
        swipe.setColorSchemeResources(R.color.gold)
        swipe.setProgressBackgroundColorSchemeResource(R.color.obsidian)
        // Only pull-to-refresh when the page is scrolled to the very top
        swipe.setOnChildScrollUpCallback { _, _ -> webView.scrollY > 0 }
        swipe.setOnRefreshListener {
            if (isOnline()) webView.reload() else { swipe.isRefreshing = false; showOffline(true) }
        }
    }

    private fun setupBackButton() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    offlineView.visibility == View.VISIBLE && webView.canGoBack() -> {
                        showOffline(false); webView.goBack()
                    }
                    webView.canGoBack() -> webView.goBack()
                    else -> {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed() // close app
                    }
                }
            }
        })
    }

    private fun loadUrlOrOffline(url: String) {
        if (url.startsWith("file:") || isOnline()) {
            showOffline(false)
            webView.loadUrl(url)
        } else {
            keepSplash = false
            showOffline(true)
        }
    }

    private fun retry() {
        if (!isOnline()) {
            Toast.makeText(this, R.string.still_offline, Toast.LENGTH_SHORT).show()
            return
        }
        showOffline(false)
        if (webView.url.isNullOrBlank() || webView.url == "about:blank") webView.loadUrl(startUrl)
        else webView.reload()
    }

    private fun showOffline(show: Boolean) {
        offlineView.visibility = if (show) View.VISIBLE else View.GONE
        swipe.visibility = if (show) View.INVISIBLE else View.VISIBLE
        if (show) { progress.visibility = View.GONE; swipe.isRefreshing = false }
    }

    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun logFcmToken() {
        // Skips quietly when google-services.json hasn't been added yet
        if (FirebaseApp.getApps(this).isEmpty()) return
        FirebaseMessaging.getInstance().subscribeToTopic("all")
        FirebaseMessaging.getInstance().token.addOnSuccessListener {
            android.util.Log.d("FCM", "Device token: $it")
        }
    }
}
