# Keep any @JavascriptInterface methods if you add a JS bridge later
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes JavascriptInterface
